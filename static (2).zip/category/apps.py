from django.apps import AppConfig


class CategoryConfig(AppConfig):
    name = 'category'
